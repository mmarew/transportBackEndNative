const driverBalanceService = require("../Services/DriverBalance.service");
const ServerResponder = require("../Utils/ServerResponder");

// Create a new driver balance record
exports.createDriverBalance = async (req, res) => {
  try {
    const result = await driverBalanceService.createDriverBalance(req.body);
    ServerResponder(res, result);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Failed to create driver balance record", error });
  }
};

// Get all driver balance records
exports.getAllDriverBalances = async (req, res) => {
  try {
    const result = await driverBalanceService.getAllDriverBalances();
    ServerResponder(res, result);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Failed to retrieve driver balance records", error });
  }
};

// Get a driver balance record by ID
exports.getDriverBalanceById = async (req, res) => {
  try {
    const result = await driverBalanceService.getDriverBalanceById(
      req.params.driverBalanceUniqueId
    );
    if (result) {
      ServerResponder(res, result);
    } else {
      ServerResponder(res, {
        message: "error",
        error: "Driver balance record not found",
      });
    }
  } catch (error) {
    ServerResponder(res, {
      message: "error",
      error: "Failed to retrieve driver balance record",
    });
  }
};

// Update a driver balance record by ID
exports.updateDriverBalance = async (req, res) => {
  try {
    const result = await driverBalanceService.updateDriverBalance(
      req.params.driverBalanceUniqueId,
      req.body
    );
    ServerResponder(res, result);
  } catch (error) {
    ServerResponder(res, {
      message: "error",
      error: "Failed to update driver balance record",
    });
  }
};

// Delete a driver balance record by ID
exports.deleteDriverBalance = async (req, res) => {
  try {
    const result = await driverBalanceService.deleteDriverBalance(
      req.params.driverBalanceUniqueId
    );
    ServerResponder(res, result);
  } catch (error) {
    ServerResponder(res, {
      message: "error",
      error: "Failed to delete driver balance record",
    });
  }
};
exports.getDriverLastBalanceByUserUniqueId = async (userUniqueId) => {
  try {
    const result =
      await driverBalanceService.getDriverLastBalanceByUserUniqueId(
        userUniqueId
      );
    ServerResponder(res, result);
  } catch (error) {
    ServerResponder(res, {
      message: "error",
      error: "Failed to retrieve driver balance record",
    });
  }
};
