require("dotenv").config();
const mysql = require("mysql2/promise");

// MySQL connection configuration
const HOST = process.env.HOST;
const USER = process.env.DB_USER;
const PASSWORD = process.env.PASSWORD;
const DATABASE = process.env.DATABASE;
const PORT = process.env.DB_PORT;
console.log("HOST ", HOST);
console.log("USER ", USER);
console.log("PASSWORD ", PASSWORD);
console.log("DATABASE ", DATABASE);

if (!HOST || !USER || !DATABASE) {
  throw new Error(
    "Missing required environment variables for database connection"
  );
}

const config = {
  host: HOST,
  user: USER,
  password: PASSWORD,
  database: DATABASE,
  waitForConnections: true,
  port: PORT,
  connectionLimit: 10,
  queueLimit: 0,
  connectTimeout: 10000, // 10 seconds
  multipleStatements: true, // Enable multiple statements
  // Socket: "/Applications/MAMP/tmp/mysql/mysql.sock",
  // socketPath: "/var/run/mysqld/mysqld.sock", // ✅ correct key
};

// Create a connection pool
let pool;

try {
  pool = mysql.createPool(config);
} catch (error) {
  console.log("Error creating database connection pool:", error);
  throw error; // Re-throw the error to ensure the application fails fast
}

// Function to get a connection from the pool
async function getConnection() {
  try {
    const connection = await pool.getConnection();
    return connection;
  } catch (error) {
    console.log("Error getting connection from the pool:", error);
    throw error;
  }
}

module.exports = {
  pool,
  getConnection,
};
